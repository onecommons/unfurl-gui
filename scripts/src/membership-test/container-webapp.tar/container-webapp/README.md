# Application Blueprint for containerized web applications

---

**Note:** You may need a developer account to deploy using this blueprint.  For more information on deploying your applications with Unfurl Cloud, visit the [developer guide](https://www.unfurl.cloud/developer-guide).

To request developer access, click on the profile drop-down on the right side of the navigation bar and choose the first option.  Open the "Request Developer Mode" link on the following page.

You can also request developer access by contacting us at [support@unfurl.cloud](mailto:support@unfurl.cloud).

## Usage

This blueprint can be used for deploying simple, self-contained applications from a container image source.

Unfurl Cloud provides multiple options for fulfilling a container image source requirement. For example: a mirrored GitHub repository, a project hosted on Unfurl Cloud, or an image from Docker Hub could all be used as container image sources.

## Incremental Deployments

Incremental deployment is a feature of Unfurl allowing deployments to be updated without needlessly provisioning or tearing down cloud resources.  This blueprint can be configured to automatically update the deployment when the container image is updated.

Container image sources based on a [code project](https://www.unfurl.cloud/developer-guide#code-projects) are built automatically by Unfurl Cloud leveraging GitLab's [Auto DevOps](https://unfurl.cloud/help/topics/autodevops/index.md) feature.  Advanced users may instead choose to write their own [`.gitlab-ci.yml`](https://unfurl.cloud/help/ci/yaml/index.md) file for greater control over the CI pipeline.

## Filling Out a Deployment Blueprint

For the general steps to deploy an application with Unfurl Cloud, see our [Getting Started guides](https://unfurl.cloud/help#guides).


### Container Options
For your container to function you will likely need specify entrypoint, volumes, etc. and define environment variables.  These options can be provided in the **Container** tab.

This blueprint assumes your application will need at least one port exposed.  The first port binding added in container will be reverse proxied to `443/https` on the host.

### Container Image Sources
To deploy using this blueprint, you must have a valid container image source.  There are currently four options for fulfilling this requirement:
  - Image from a container registry
  - Image from an Unfurl Cloud hosted registry
  - Image built from an Unfurl Cloud project
  - Image built from a mirrored GitHub repository


#### Container Registry
To deploy with an image from a container registry, simply select "Container Registry" from the image source dialog and fill in the credential information as necessary.

#### Unfurl Cloud Registry
To deploy an image from an Unfurl Cloud registry, your account must be authorized to access the registry.

<!-- TODO: document how to invite users to access a registry -->

####  Unfurl Cloud Project
To deploy an image from an Unfurl Cloud project, you can [create a project](https://unfurl.cloud/projects/new) or push an existing repository directly to a namespace you are permitted to use.

Make sure you have an image built for the branch you want to use before deploying.  This should happen automatically via [Auto DevOps](https://unfurl.cloud/help/topics/autodevops/index.md), but may need to be re-enabled if errors occurred during a build.

#### Mirrored GitHub Repository
When deploying an image from a GitHub repository, you will be prompted to authenticate in order to select and set up a project for mirroring.  You must be authorized to create webhooks on the chosen GitHub project for the mirroring to function.

After the mirror is created, any source changes to the upstream GitHub will be reflected in the mirror on Unfurl Cloud and the [Auto DevOps](https://unfurl.cloud/help/topics/autodevops/index.md) pipeline will attempt to build new images.

<!--
### Details


To simplify the deployment process, we have set default values for several required inputs and hidden them from the UI. The remaining inputs are exposed under "Details", and must be filled in:

| Input Name                    | Default Value    |
|-------------------------------|------------------|
| WordPress Admin Username      | `wordpress`      |
| WordPress Admin Password      | (auto-generated) |
| WordPress Admin Email         | (none)           |
| WordPress Version             | `5.9.3`          |
| Database Password             | (auto-generated) |
| Subdomain *(see [DNS](#dns))* | `www`            |

Below is a list of the hidden inputs and their default values:

| Input Name       | Default Value |
|------------------|---------------|
| Database User    | `wordpress`   |
| Database Name    | `wordpress`   |
| Database Type    | `mysql`       |
| Database Version | `8.0`         |

### Components

Each application blueprint includes **components**. These are the required and optional resources for the application. In most cases, there is more than one way to fulfill a component requirement. Common components include Compute, DNS, Database, and Mail Server:

After selecting a deployment blueprint, you will be prompted to fulfill the requirements and configure the deployment to your needs.

#### Compute

WordPress requires the following compute VM resources:

- At least 1 CPU
- At least 1024 MB (1 GB) of RAM
- At least 10 GB of hard disk space

### DNS

A DNS provider must be specified for the deployed site to be accessible via a domain name.

Supported DNS providers are:

- Google Cloud DNS
- DigitalOcean DNS
- AWS Route53
- Azure DNS

All providers require a domain name to use. ***Note:** the domain must be registered to that service.*

The `Subdomain` input above will be used to register a new subdomain under the given domain. For example, given the subdomain `wp-example` and domain zone `mysite.com`, the site will be accessible at `wp-example.mysite.com`.

### Database: MySQL or MariaDB

WordPress can use either of these databases:

| Database | Supported Versions |
|----------|--------------------|
| MySQL    | `5.7`, `8.0`       |
| MariaDB  | `10.3` to `10.9`   |

### "Extra" Components

Optional blueprint components can be found under the "Extras" tab when filling out the blueprint. These components can offer extra features or enhancements to the site, but are not required for a basic deployment.

#### Mail Server

WordPress optionally requires a mail server to send out emails.

Two mail providers are supported, with their needed inputs detailed below:


**SendGrid:**

| Input   | Description                                                                                    |
|---------|------------------------------------------------------------------------------------------------|
| API Key | This can be created at [SendGrid account settings](https://app.sendgrid.com/settings/api_keys) |

**Generic SMTP Server:**

| Input     | Description                                                                     |
|-----------|---------------------------------------------------------------------------------|
| SMTP Host | Name of the mail server, e.g. `smtp.someprovider.com`                           |
| User Name | Usually the email to send as. Double check the documentation for your provider! |
| Secret    | The password or login token to authenticate with.                               |
| Protocol  | Either `ssl` or `tls`, probably `tls`.                                          |

**Gmail:**

Use Generic SMTP Server with the following inputs:

| Input     | Value                                       |
|-----------|---------------------------------------------|
| SMTP Host | `smtp.gmail.com`                            |
| User Name | Gmail username (email without `@gmail.com`) |
| Secret    | Gmail password                              |
| Protocol  | `tls`                                       |
-->
