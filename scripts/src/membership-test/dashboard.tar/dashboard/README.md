# Your dashboard project

This project contains your environment settings and deployment history. It is managed by unfurl.cloud so it not recommended you make manual changes to it. 

If you clone this project locally you can use it with your local installation of the [unfurl](https://unfurl.run) command-line. Just remember to push your changes if you want to keep it in sync with unfurl.cloud.
